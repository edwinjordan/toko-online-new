<html>
    <head>
        <title><?=$title?></title>
        <style>
        .user_info{
            margin:10px auto 10px auto;
            width: 400px;
            padding: 10px;
            background-color: #D8DFEA;
        }
        .user_info_header, .pdf_download{
            text-align: center;
            padding:10px;
        }
        </style>
    </head>
    <body>
        <div class="body">