<?php echo $this->session->flashdata('item'); ?>











<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsepanduan" aria-expanded="true" aria-controls="collapseOne">
          Panduan
        </a>
      </h4>
    </div>
    <div id="collapsepanduan" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
       	 <form action="<?php echo base_url('profil/update_panduan/1')?>" method="POST">
        <textarea name='panduan' class="ckeditor" style='width: 800px; height: 350px;'><?php echo $data3[0]->panduan?></textarea>
      	<br>
      	<button type="submit" class="btn btn-primary" style="float:right;" >Save</button>
      </form>
       
      </div>
    </div>
  </div>
 



<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseakun" aria-expanded="true" aria-controls="collapseOne">
          Akun Bank
        </a>
      </h4>
    </div>
    <div id="collapseakun" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">


        <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            Tambah Akun
          </button>

          <!-- Modal -->
          <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
               <form class="form-horizontal" method="POST" action="<?php echo base_url('profil/tambah_akun_bank') ?>">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Tambah Akun Bank</h4>
                  </div>
                  <div class="modal-body">
                   
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Jenis Bank</label>
                        <div class="col-sm-10">
                          <input type="text" required=""  class="form-control" name="jenis_bank" placeholder="Jenis Bank">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Atas Nama</label>
                        <div class="col-sm-10">
                          <input type="text"  required="" class="form-control" name="atas_nama_bank" placeholder="Atas Nama">
                        </div>
                      </div>

                       <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">No Rekening</label>
                        <div class="col-sm-10">
                          <input type="text"  required="" class="form-control" name="no_rekening" placeholder="No Rekening">
                        </div>
                      </div>
                      
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                  </div>

                </form>
              </div>
            </div>
          </div>








         <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Jenis Bank</th>
              <th>Atas Nama</th>
              <th>No Rekening</th>
              <th>Opsi</th>
            </tr>
          </thead>
          <tbody>

          <?php 
          $i=1;

          foreach ($data_bank as $key ) { ?>
           
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $key['jenis_bank'] ?></td>
              <td><?php echo $key['atas_nama_bank'] ?></td>
              <td><?php echo $key['no_rekening'] ?></td>
              <td>
              <div class="btn-group" role="group" aria-label="...">
                <a href="<?php echo base_url('profil/delete_akun/'.$key['id_data']) ?>" type="button" class="btn btn-danger" onclick="javascript: return confirm('Anda yakin ingin menghapus data akun bank <?php echo $key['jenis_bank'] ?>?')" >Hapus</a>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_bank<?php echo $i ?>" >Edit</button>
              </div>
              </td>
            </tr>






            <!-- Modal -->
          <div class="modal fade" id="edit_bank<?php echo $i ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                  <form method="POST" action="<?php echo base_url('profil/edit_bank') ?>" > 
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Edit Akun Bank</h4>
                  </div>
                  <div class="modal-body">
                   

                     <input type="hidden" required=""  class="form-control" name="id_data" value="<?php echo $key['id_data'] ?>">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Jenis Bank</label>
                        <input type="text" required=""  class="form-control" name="jenis_bank" value="<?php echo $key['jenis_bank'] ?>">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Atas Nama</label>
                        <input type="text" class="form-control" required="" name="atas_nama_bank" value="<?php echo $key['atas_nama_bank'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">No Rekening</label>
                        <input type="text" class="form-control" required="" name="no_rekening" value="<?php echo $key['no_rekening'] ?>" >
                      </div>
                       
                      
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                  </div>
                   </form>

              
              </div>
            </div>
          </div>



          <?php
          $i++;
           } ?>
            
          </tbody>
        </table>
       
      </div>
    </div>
  </div>
 



















<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          About Us
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
      <form action="<?php echo base_url('profil/update_konten/1')?>" method="POST">
        <textarea name='deskripsi' class="ckeditor" style='width: 800px; height: 350px;'><?php echo $data1[0]->tentang?></textarea>
      	<br>
      	<button type="submit" class="btn btn-primary" style="float:right;" >Save</button>
      </form>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Aturan Umum
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
        <form action="<?php echo base_url('profil/update_aturan/1')?>" method="POST">
        <textarea name='aturan' class="ckeditor" style='width: 800px; height: 350px;'><?php echo $data2[0]->aturan?></textarea>
      	<br>
      	<button type="submit" class="btn btn-primary" style="float:right;" >Save</button>
      </form>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Contact
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
       <form class="form-horizontal" method="post" action="<?php echo base_url('profil/update_contact')?>" >
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-2 control-label">No Telp</label>
		    <div class="col-sm-10">
		      <input type="number" name="telp" class="form-control" required="" id="inputEmail3" placeholder="No Telp" value="<?php echo $data[0]['no_telp']?>">
		    </div>
		  </div>
		  
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-2 control-label">Alamat</label>
		    <div class="col-sm-10">
		    	<textarea name="alamat" class="form-control" required=""  ><?php echo $data[0]['alamat']?></textarea>
		     
		    </div>
		  </div>
		  
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
		    <div class="col-sm-10">
		      <input type="email" name="email" class="form-control" required=""  placeholder="Email" value="<?php echo $data[0]['Email']?>">
		    </div>
		  </div>
		  
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-primary">Save</button>
		    </div>
		  </div>
		</form>
      </div>
    </div>
  </div>
</div>
