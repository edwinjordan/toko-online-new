<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
	public function index()
	{    	
		if($this->session->userdata("logged_in") == TRUE){
			$d['laporan'] = $this->cilinaya_model->page_query("`order`")->result_array();
			$d['content'] = "laporan/laporan_view";
			$this->load->view('dashboard',$d);
       //$this->load->view('laporan/laporan_view');

		}else{
			$desk = base_url("");
			$msg = "Maaf Anda Belum Login.";
			echo '<script type="text/javascript">
			alert("' . $msg . '"); 
			location.href = "' . $desk . '"; 
		</script>';
	}
}

public function ajax_tabel()
{

	if (!$this->input->is_ajax_request()) {
		exit('No direct script access allowed');
	} else {
//            panggil dulu library datatablesnya

		$this->load->library('datatables_ssp');

//            atur nama tablenya disini
		$table = 'order';

            // Table's primary key
		$primaryKey = 'id_order';

            // Array of database columns which should be read and sent back to DataTables.
            // The `db` parameter represents the column name in the database, while the `dt`
            // parameter represents the DataTables column identifier. In this case simple
            // indexes

		/*
		SELECT
		`order`.id_order,
		`order`.tgl_order,
		`order`.status_order,
		`order`.status_kirim,
		produk.nama_produk,
		detail_order.jumlah_produk
		FROM
		`order`
		INNER JOIN detail_order ON order.id_order = detail_order.id_order
		INNER JOIN produk ON detail_order.id_produk = produk.id_produk
		*/

		$columns = array(
			
			array('db' => 'status_order', 'dt' => 'status_order'),
			array('db' => 'status_kirim', 'dt' => 'status_kirim'),
			array('db' => 'id_order', 'dt' => 'DT_RowId'),
			array('db' => 'tgl_order', 'dt' => 'tgl_order'),
			);

            // SQL server connection information
		$CI =& get_instance();
		$CI->load->database();
		$host=$CI->db->hostname;
		$user=$CI->db->username;
		$pass=$CI->db->password;
		$db=$CI->db->database;
        /////////////////////
		$sql_details = array(
			'user' => $user,
			'pass' => $pass,
			'db' => $db,
			'host' => $host
			);
		$data = Datatables_ssp::complex($_GET, $sql_details, $table, $primaryKey, $columns,null, "`id_order` LIKE 'T%' OR `id_order` LIKE 'P%'");
		echo json_encode($data);
		}
	}
	function test()
	{
	 // give the config name here (hostname).
	}

}