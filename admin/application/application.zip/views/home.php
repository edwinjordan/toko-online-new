 
    <div class="row">
    	<div class="span7">
        	<div class="clearfix cols-1">
        	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
                <link href="<?php echo base_url("assets/admin-webmaster/css/"); ?>/custume.css" rel="stylesheet" type="text/css" />
				<link href="<?php echo base_url("assets/admin-webmaster/css/ui.datepicker.css"); ?>" rel="stylesheet" type="text/css" />
				<link href="<?php echo base_url("assets/admin-webmaster/css/ui.theme.css"); ?>" rel="stylesheet" type="text/css" />
				<link href="<?php echo base_url("assets/admin-webmaster/css/ui.core.css"); ?>" rel="stylesheet" type="text/css" />
				<script src="<?php echo base_url("assets/admin-webmaster"); ?>/js/jquery.ui.draggable.js" type="text/javascript"></script>
				<!-- Core files -->
				<script src="<?php echo base_url("assets/admin-webmaster"); ?>/js/jquery.alerts.js" type="text/javascript"></script>
				<link href="<?php echo base_url("assets/admin-webmaster"); ?>/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
				<script src="<?php echo base_url("assets/admin-webmaster/js/ui.datepicker.js"); ?>"></script>

<div class="formLayouts clearfix" style="padding: 10px;">
	<h1 style="border-bottom:2px solid ">Halo Admin!</h1>
	<div class="panel-body table-responsive">
		Selamat Datang di Dashboard Admin
</div>

            </div>
            
        </div>    
          


