
 
  <!-- catg header banner section -->
  <section id="aa-catg-head-banner">
   <img src="<?php echo base_url() ?>assets/img/fashion/fashion-header-bg-8.jpg" alt="fashion img">
   <div class="aa-catg-head-banner-area">
     <div class="container">
      <div class="aa-catg-head-banner-content">
        <h2>Konfirmasi Pembayaran</h2>
        <!-- <ol class="breadcrumb">
          <li><a href="index.html">Home</a></li>                   
          <li class="active">Wishlist</li>
        </ol> -->
      </div>
     </div>
   </div>
  </section>
  <!-- / catg header banner section -->

 <!-- Cart view section -->
 <section id="cart-view">
   <div class="container">
     <div class="row">
      <div class="col-md-12">
         <div class="cart-view-area">
           <div class="cart-view-table aa-wishlist-table">
            
             <form action="">
               <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr class="cart_menu">
              
                        <h4 class="title">ID Order Anda: <?php echo $id_order ?></h4>
                        <h4 class="title"><strong>Mohon simpan ID order anda,sebelum menutup halaman ini</strong></h4>
                        <h4 class="title">Data Bank Untuk Kirim Uang</h4>
                      </tr>
                    </thead>
                    <thead>
                      <tr>
                        <td><strong>BCA</strong></td>
                        <td>No. rekening 1111111111111111 A.N Elecomp</td>
                      </tr>
                      <tr>
                        <td><strong>BRI</strong></td>
                        <td>No. rekening 1111111111111111 A.N Elecomp</td>
                      </tr>
                      <tr>
                        <td><strong>BNI</strong></td>
                        <td>No. rekening 1111111111111111 A.N Elecomp</td>
                      </tr>
                      <tr>
                        <td><strong>Mandiri</strong></td>
                        <td>No. rekening 1111111111111111 A.N Elecomp</td>
                      </tr>
                      <tr>
                        <td><strong>BTN</strong></td>
                        <td>No. rekening 1111111111111111 A.N Elecomp</td>
                      </tr>
                     
                    </thead>
                  
                  </table>
                </div>
             </form>             
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- / Cart view section



