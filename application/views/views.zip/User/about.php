<html>

 
  <!-- catg header banner section -->
  <section id="aa-catg-head-banner">
     <div class="container">
     
        <div class="panel panel-default" style="margin-top: 50px;">
          <div class="panel-heading" style="    color: #63625b;
    background-color: #ffd900;
    border-color: #dddddd;" >
            <h3 class="panel-title"><?php echo $label; ?> Jevera</h3>
          </div>
          <div class="panel-body">
          <div class="row">
            <div class="col-md-3"><span><img src="<?php echo base_url(); ?>/assets/img/logocart.png" class="img-responsive" style="width: 150px" ></span></div>
            <div class="col-md-9">
               <p style="    font-size: 21px;" > <?php echo $data; ?></p>
            </div>
          </div>
          
           
          </div>
        </div>

     </div>
  </section>
  <!-- / catg header banner section -->

  <!-- / Subscribe section -->

</html>